let minutes = document.querySelector('.minutes')
let seconds = document.querySelector('.seconds')
let hours = document.querySelector('.hours')
let contador = 60
let contadorMinutos = 60
let contadorHoras = 10
let clockContainer = document.querySelector('.clock')
let passWord = document.querySelector('.mainText')

setInterval(()=>{
  contador -=1
  console.log(contador)
  if(contador >= 10){
    seconds.textContent = contador
  }else if(contador < 10 && contador >= 0){
    seconds.textContent = `0${contador}`
  }else if(contador < 0){
    seconds.textContent = `60`
    contador = 60
  }
}, 1000)
setInterval(()=>{
  contadorMinutos -= 1
  if(contadorMinutos >= 10){
    minutes.textContent = `${contadorMinutos}`
  }
  else if(contadorMinutos < 10 && contadorMinutos >= 0){
      minutes.textContent = `0${contadorMinutos}`
  }
  else if(contador < 0){
    minutes.textContent = `60`
    contadorMinutos = 60
  }
}, 60000)


setInterval(()=>{
  contadorHoras -= 1
  if(contadorHoras < 10 && contadorHoras >= 0){
    hours.textContent = `0${contadorHoras}`
  }
  else if(contadorHoras < 0){
    hours.textContent = `10`
    contadorHoras = 10
  }
}, 3600000)

setTimeout(()=>{
  clockContainer.style.display = 'none'
  passWord.classList.add('removeBlur')
}, 39660000)